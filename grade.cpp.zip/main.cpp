/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
int main()
{
int marks;
cout<<"Enter your marks";
cin>>marks;
if(marks<25)
cout<<" Your grade is :F";
else if (marks>=25&&marks<45)
cout<<"Your grade is :E";
else if (marks>=45&&marks<50)
cout<<"Your grade is :D";
else if (marks>=50&&marks<60)
cout<<"Your grade is :C";
else if (marks>=60&&marks<80)
cout<<"Your grade is :B";
else 
cout<<"Your grade is :A";

    return 0;
}
